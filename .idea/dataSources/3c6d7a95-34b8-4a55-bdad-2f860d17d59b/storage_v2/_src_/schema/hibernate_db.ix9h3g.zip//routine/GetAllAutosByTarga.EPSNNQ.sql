create
    definer = root@localhost procedure GetAllAutosByTarga(IN targa varchar(255))
BEGIN
	select * from hibernate_db.auto where auto.targa=targa;
END;

